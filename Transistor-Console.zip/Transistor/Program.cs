﻿using System;

namespace Transistor
{
    class Program
    {
        static void Main(string[] args)
        {
            //Ejecución del juego
            Transistor game = new Transistor();
            game.Run();
        }
    }
}
