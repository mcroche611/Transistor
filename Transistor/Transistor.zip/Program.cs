﻿using System;

namespace Transistor
{
    class Program
    {
        static void Main(string[] args)
        {
           // Console.WriteLine("Hello World!  ⬌ ↓ ↑ ← 🠐 → 😀 😈 ★ ♖ ➢ ");
            //Tester t = new Tester();
            //Console.Clear();
            //t.TestBattlefieldShowNormal();
            Transistor game = new Transistor();
            Console.Clear();
            game.Run();
        }
    }
}
